Please use the AEM 6.1 Jar file from Scene7 location:
Course Material-->AEM-->6.1-->AEM 6.1 JAR file